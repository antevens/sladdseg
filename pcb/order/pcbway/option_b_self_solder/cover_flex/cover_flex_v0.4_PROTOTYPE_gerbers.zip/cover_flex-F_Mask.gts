G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-10-11T21:10:04+00:00*
G04 #@! TF.ProjectId,cover_flex,636f7665-725f-4666-9c65-782e6b696361,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-10-11 21:10:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.140000X-0.140000X-0.170000X0.140000X-0.170000X0.140000X0.170000X-0.140000X0.170000X0*%
%ADD11R,3.600000X6.650000*%
%ADD12C,2.600000*%
%ADD13RoundRect,0.150000X-0.512500X-0.150000X0.512500X-0.150000X0.512500X0.150000X-0.512500X0.150000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,C4*
X-13680000Y-700000D03*
X-12720000Y-700000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J4*
X-11200000Y-25050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X-13200000Y-8900000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X-13200000Y-13500000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,C3*
X-15480000Y-5700000D03*
X-14520000Y-5700000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,U1*
X-14737500Y-2350000D03*
X-14737500Y-3300000D03*
X-14737500Y-4250000D03*
X-12462500Y-4250000D03*
X-12462500Y-2350000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J3*
X11200000Y-25050000D03*
G04 #@! TD*
M02*
