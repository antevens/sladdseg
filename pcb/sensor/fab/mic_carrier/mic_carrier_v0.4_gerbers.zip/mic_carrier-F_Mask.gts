G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-10-11T04:56:22+00:00*
G04 #@! TF.ProjectId,mic_carrier,6d69635f-6361-4727-9269-65722e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-10-11 04:56:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.150000X-0.750000X-0.350000X0.750000X-0.350000X0.750000X0.350000X-0.750000X0.350000X0*%
%ADD11C,0.500000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X-3500000Y1500000D03*
X-3500000Y0D03*
X-3500000Y-1500000D03*
X3500000Y1500000D03*
X3500000Y0D03*
X3500000Y-1500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,MK1*
X0Y0D03*
G04 #@! TD*
M02*
